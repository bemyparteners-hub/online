// App.jsx — Configurateur de façonnage aluminium
// Shell : toolbar haut, panneau gauche (profils), canvas central (2D + 3D), panneau droit (cotes + matière + récap)

const { useState, useEffect, useMemo } = React;

const BAR_LENGTHS = [];

// Valeurs de tweak — système pour persistance
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "accentColor": "#2b66d9",
  "showGrid": true,
  "show3D": true
}/*EDITMODE-END*/;

function cloneProfile(p) {
  return {
    ...p,
    segments: p.segments.map(s => ({ ...s })),
    bends: p.bends.map(b => ({ ...b })),
  };
}

function App() {
  const PROFILES = window.AluProfiles;
  const G = window.AluGeom;

  const [selectedProfileId, setSelectedProfileId] = useState(PROFILES[0].id);
  const [profile, setProfile] = useState(() => cloneProfile(PROFILES[0]));
  const [hoverSeg, setHoverSeg] = useState(null);

  // Matière — code libre selon charte de nomenclature (ex. AL15-7016M)
  const [materialCode, setMaterialCode] = useState("AL15-7016M");
  const [barLength, setBarLength] = useState(3000);
  const [quantity, setQuantity] = useState(1);

  // Épaisseur extraite du code matière (AL15 => 1.5 mm) pour le calcul de poids uniquement
  const thicknessMmFromCode = useMemo(() => {
    const m = materialCode.match(/AL\s*(\d+)/i);
    if (m) {
      const v = parseInt(m[1], 10);
      // AL10 → 1.0 mm, AL15 → 1.5 mm, AL20 → 2.0 mm…
      return v >= 10 ? v / 10 : v;
    }
    return 1.5;
  }, [materialCode]);

  // Mode : schema (cotes A,B,C) ou libre (édition de plis)
  const [mode, setMode] = useState("schema");
  const [activeView, setActiveView] = useState("both"); // "2d", "3d", "both"

  // Tweaks state
  const [tweaks, setTweaks] = useState(TWEAK_DEFAULTS);
  const [tweaksOpen, setTweaksOpen] = useState(false);

  useEffect(() => {
    function onMsg(e) {
      if (!e.data || !e.data.type) return;
      if (e.data.type === "__activate_edit_mode") setTweaksOpen(true);
      if (e.data.type === "__deactivate_edit_mode") setTweaksOpen(false);
    }
    window.addEventListener("message", onMsg);
    window.parent.postMessage({ type: "__edit_mode_available" }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  function updateTweak(key, value) {
    const next = { ...tweaks, [key]: value };
    setTweaks(next);
    window.parent.postMessage({ type: "__edit_mode_set_keys", edits: { [key]: value } }, "*");
  }

  function selectProfile(id) {
    const p = PROFILES.find(x => x.id === id);
    if (!p) return;
    setSelectedProfileId(id);
    setProfile(cloneProfile(p));
  }

  function updateSegmentLength(idx, value) {
    const v = Math.max(1, parseFloat(value) || 0);
    setProfile(prev => ({
      ...prev,
      segments: prev.segments.map((s, i) => i === idx ? { ...s, length: v } : s),
    }));
  }

  function updateBendAngle(idx, value) {
    const v = parseFloat(value) || 0;
    setProfile(prev => ({
      ...prev,
      bends: prev.bends.map((b, i) => i === idx ? { ...b, angle: v } : b),
    }));
  }

  function addSegment() {
    setProfile(prev => {
      const newSegments = [...prev.segments, { length: 30, label: "" }];
      const newBends = [...prev.bends, { angle: -90 }];
      newSegments.forEach((s, i) => s.label = G.label(i));
      return { ...prev, segments: newSegments, bends: newBends };
    });
  }

  function addBendAfter(idx) {
    setProfile(prev => {
      const newSegments = [...prev.segments];
      const newBends = [...prev.bends];
      const insertAt = idx + 1;
      newSegments.splice(insertAt, 0, { length: 30, label: "" });
      newBends.splice(insertAt - 1 < 0 ? 0 : insertAt - 1 + 1, 0, { angle: -90 });
      // Recalcule labels
      newSegments.forEach((s, i) => s.label = G.label(i));
      return { ...prev, segments: newSegments, bends: newBends };
    });
  }

  function removeSegment(idx) {
    setProfile(prev => {
      if (prev.segments.length <= 2) return prev;
      const newSegments = prev.segments.filter((_, i) => i !== idx);
      const newBends = [...prev.bends];
      // Supprime le pli adjacent (celui avant ce segment, ou le premier pli si idx=0)
      const bendToRemove = idx === 0 ? 0 : idx - 1;
      if (newBends.length > 0) newBends.splice(bendToRemove, 1);
      newSegments.forEach((s, i) => s.label = G.label(i));
      return { ...prev, segments: newSegments, bends: newBends };
    });
  }

  // Calculs récap
  const totalDev = useMemo(() => G.developpedLength(profile.segments), [profile]);
  const thicknessMm = thicknessMmFromCode;
  const estWeight = useMemo(
    () => G.weight(profile.segments, thicknessMm, barLength) * quantity,
    [profile, thicknessMm, barLength, quantity]
  );

  return (
    <div className="app">
      {/* TOOLBAR */}
      <header className="toolbar">
        <div className="toolbar-left">
          <div className="logo">
            <div className="logo-mark">⌐</div>
            <div>
              <div className="logo-title">PLIFORM</div>
              <div className="logo-sub">Configurateur façonnage aluminium</div>
            </div>
          </div>
        </div>
        <div className="toolbar-center">
          <div className="proj-info">
            <span className="proj-label">PROJET</span>
            <span className="proj-name">Nouveau façonnage</span>
            <span className="proj-sep">·</span>
            <span className="proj-date">{new Date().toLocaleDateString("fr-FR")}</span>
          </div>
        </div>
        <div className="toolbar-right">
          <button className="tb-btn">
            <span className="kbd">⌘S</span> Enregistrer
          </button>
          <button className="tb-btn primary">Ajouter au devis</button>
        </div>
      </header>

      <div className="main-layout">
        {/* PANNEAU GAUCHE — Bibliothèque de profils */}
        <aside className="sidebar left">
          <div className="panel-head">
            <span className="panel-title">BIBLIOTHÈQUE</span>
            <span className="panel-count">{PROFILES.length}</span>
          </div>

          <div className="profile-list">
            {PROFILES.map(p => (
              <button
                key={p.id}
                className={`profile-card ${selectedProfileId === p.id ? "active" : ""}`}
                onClick={() => selectProfile(p.id)}
              >
                <div className="profile-thumb">
                  <ProfileThumb profile={p} />
                </div>
                <div className="profile-meta">
                  <div className="profile-name">{p.name}</div>
                  <div className="profile-sub">{p.subtitle}</div>
                </div>
              </button>
            ))}
          </div>

          <div className="panel-head" style={{ marginTop: 16 }}>
            <span className="panel-title">MODE DE SAISIE</span>
          </div>
          <div className="mode-switch">
            <button
              className={`mode-btn ${mode === "schema" ? "active" : ""}`}
              onClick={() => setMode("schema")}
            >
              Cotes A,B,C
            </button>
            <button
              className={`mode-btn ${mode === "libre" ? "active" : ""}`}
              onClick={() => setMode("libre")}
            >
              Édition libre
            </button>
          </div>
        </aside>

        {/* CANVAS CENTRAL */}
        <main className="canvas">
          <div className="canvas-head">
            <div className="breadcrumb">
              <span>{profile.name}</span>
              <span className="sep">›</span>
              <span className="muted">{profile.segments.length} segments · {profile.bends.length} plis</span>
            </div>
            <div className="view-toggle">
              <button className={`vt ${activeView === "2d" ? "active" : ""}`} onClick={() => setActiveView("2d")}>
                <span className="vt-ic">◫</span> Coupe 2D
              </button>
              <button className={`vt ${activeView === "3d" ? "active" : ""}`} onClick={() => setActiveView("3d")}>
                <span className="vt-ic">⬠</span> Isométrie
              </button>
              <button className={`vt ${activeView === "both" ? "active" : ""}`} onClick={() => setActiveView("both")}>
                <span className="vt-ic">⊞</span> Double vue
              </button>
            </div>
          </div>

          <div className={`views views-${activeView}`}>
            {(activeView === "2d" || activeView === "both") && (
              <div className="view-frame">
                <div className="view-label">
                  <span className="vl-num">01</span>
                  <span className="vl-txt">VUE EN COUPE · PROFIL PLIÉ</span>
                  <span className="vl-meta">1:1 AUTO</span>
                </div>
                <View2D
                  segments={profile.segments}
                  bends={profile.bends}
                  thickness={thicknessMm * 2}
                  highlightIndex={hoverSeg}
                  onSegmentHover={setHoverSeg}
                  onSegmentLeave={() => setHoverSeg(null)}
                />
              </div>
            )}
            {(activeView === "3d" || activeView === "both") && (
              <div className="view-frame">
                <div className="view-label">
                  <span className="vl-num">02</span>
                  <span className="vl-txt">VUE ISOMÉTRIQUE · BARRE {barLength} mm</span>
                  <span className="vl-meta">ISO 30°</span>
                </div>
                <View3D
                  segments={profile.segments}
                  bends={profile.bends}
                  barLength={barLength}
                  thickness={thicknessMm * 2}
                />
              </div>
            )}
          </div>

          {/* Barre de status bas */}
          <div className="statusbar">
            <div className="sb-item">
              <span className="sb-lbl">DÉVELOPPÉ</span>
              <span className="sb-val">{totalDev.toFixed(1)} mm</span>
            </div>
            <div className="sb-sep" />
            <div className="sb-item">
              <span className="sb-lbl">PLIS</span>
              <span className="sb-val">{profile.bends.length}</span>
            </div>
            <div className="sb-sep" />
            <div className="sb-item">
              <span className="sb-lbl">MATIÈRE</span>
              <span className="sb-val">{materialCode || "—"}</span>
            </div>
            <div className="sb-sep" />
            <div className="sb-item">
              <span className="sb-lbl">POIDS UNIT.</span>
              <span className="sb-val">{(estWeight / quantity).toFixed(2)} kg</span>
            </div>
            <div className="sb-sep" />
            <div className="sb-item">
              <span className="sb-lbl">TOTAL {quantity > 1 ? `×${quantity}` : ""}</span>
              <span className="sb-val accent">{estWeight.toFixed(2)} kg</span>
            </div>
            <div className="sb-spacer" />
          </div>
        </main>

        {/* PANNEAU DROIT — Cotes + matière */}
        <aside className="sidebar right">
          <div className="tabs">
            <button className="tab active">Paramètres</button>
          </div>

          {/* COTES */}
          <section className="section">
            <div className="panel-head">
              <span className="panel-title">COTES (mm)</span>
              <span className="panel-count">{profile.segments.length}</span>
            </div>

            <div className="dim-list">
              {profile.segments.map((seg, i) => (
                <div
                  key={i}
                  className={`dim-row ${hoverSeg === i ? "hover" : ""}`}
                  onMouseEnter={() => setHoverSeg(i)}
                  onMouseLeave={() => setHoverSeg(null)}
                >
                  <div className="dim-label">{seg.label}</div>
                  <input
                    type="number"
                    className="dim-input"
                    value={seg.length}
                    min="1"
                    step="1"
                    onChange={e => updateSegmentLength(i, e.target.value)}
                  />
                  <div className="dim-unit">mm</div>
                  {profile.segments.length > 2 && (
                    <button className="dim-rm" title="Supprimer cette cote" onClick={() => removeSegment(i)}>−</button>
                  )}
                  {i < profile.segments.length - 1 && (
                    <button className="dim-add" title="Insérer une cote après" onClick={() => addBendAfter(i)}>+</button>
                  )}
                </div>
              ))}
            </div>
            <button className="add-seg-btn" onClick={addSegment} title="Ajouter une cote">
              <span className="add-seg-plus">+</span>
              Ajouter une cote <span className="add-seg-next">{G.label(profile.segments.length)}</span>
            </button>
          </section>

          {/* ANGLES */}
          <section className="section">
            <div className="panel-head">
              <span className="panel-title">ANGLES DE PLI (°)</span>
              <span className="panel-count">{profile.bends.length}</span>
            </div>
            <div className="dim-list">
              {profile.bends.map((b, i) => (
                <div key={i} className="dim-row">
                  <div className="dim-label alt">P{i + 1}</div>
                  <div className="ang-meta">
                    {profile.segments[i]?.label} → {profile.segments[i + 1]?.label}
                  </div>
                  <input
                    type="number"
                    className="dim-input small"
                    value={b.angle}
                    step="1"
                    onChange={e => updateBendAngle(i, e.target.value)}
                  />
                  <div className="dim-unit">°</div>
                </div>
              ))}
            </div>
          </section>

          {/* MATIÈRE — saisie libre selon charte de nomenclature */}
          <section className="section">
            <div className="panel-head">
              <span className="panel-title">MATIÈRE</span>
              <span className="panel-count mono-hint">nomenclature</span>
            </div>
            <div className="mat-row">
              <div className="mat-label">MAT</div>
              <input
                type="text"
                className="mat-input"
                value={materialCode}
                placeholder="ex. AL15-7016M"
                onChange={e => setMaterialCode(e.target.value.toUpperCase())}
                spellCheck={false}
              />
            </div>
            <div className="mat-hint">
              Ex. <code>AL15-7016M</code> · <code>AL20-9010L</code> · <code>AL10-BRUT</code>
            </div>
          </section>

          {/* BARRE & QUANTITÉ */}
          <section className="section">
            <div className="panel-head">
              <span className="panel-title">BARRE & QUANTITÉ</span>
            </div>

            <label className="field-label">Longueur</label>
            <div className="dim-row" style={{ padding: "0 14px 8px" }}>
              <div className="dim-label alt">L</div>
              <input
                type="number"
                className="dim-input"
                value={barLength}
                min="1"
                step="10"
                onChange={e => setBarLength(Math.max(1, parseFloat(e.target.value) || 1))}
              />
              <div className="dim-unit">mm</div>
            </div>

            <label className="field-label">Quantité</label>
            <div className="qty-row">
              <button className="qty-btn" onClick={() => setQuantity(q => Math.max(1, q - 1))}>−</button>
              <input
                type="number"
                className="qty-input"
                value={quantity}
                min="1"
                onChange={e => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
              />
              <button className="qty-btn" onClick={() => setQuantity(q => q + 1)}>+</button>
            </div>
          </section>

          {/* RÉCAP */}
          <section className="section recap">
            <div className="panel-head">
              <span className="panel-title">RÉCAPITULATIF</span>
            </div>
            <div className="recap-grid">
              <div className="recap-row">
                <span className="recap-k">Développé</span>
                <span className="recap-v">{totalDev.toFixed(1)} mm</span>
              </div>
              <div className="recap-row">
                <span className="recap-k">Nb plis</span>
                <span className="recap-v">{profile.bends.length}</span>
              </div>
              <div className="recap-row">
                <span className="recap-k">Surface tôle (u.)</span>
                <span className="recap-v">{(totalDev * barLength / 1e6).toFixed(3)} m²</span>
              </div>
              <div className="recap-row">
                <span className="recap-k">Poids unitaire</span>
                <span className="recap-v">{(estWeight / quantity).toFixed(2)} kg</span>
              </div>
              <div className="recap-row total">
                <span className="recap-k">Total × {quantity}</span>
                <span className="recap-v">{estWeight.toFixed(2)} kg</span>
              </div>
            </div>
          </section>
        </aside>
      </div>

      {/* TWEAKS PANEL */}
      {tweaksOpen && (
        <div className="tweaks">
          <div className="tweaks-head">
            <span>Tweaks</span>
            <button onClick={() => setTweaksOpen(false)}>×</button>
          </div>
          <div className="tweaks-body">
            <label className="tw-row">
              <span>Couleur d'accent</span>
              <input
                type="color"
                value={tweaks.accentColor}
                onChange={e => {
                  updateTweak("accentColor", e.target.value);
                  document.documentElement.style.setProperty("--accent", e.target.value);
                }}
              />
            </label>
            <label className="tw-row">
              <span>Vue 3D visible</span>
              <input
                type="checkbox"
                checked={tweaks.show3D}
                onChange={e => {
                  updateTweak("show3D", e.target.checked);
                  if (!e.target.checked) setActiveView("2d");
                  else setActiveView("both");
                }}
              />
            </label>
            <label className="tw-row">
              <span>Grille technique</span>
              <input
                type="checkbox"
                checked={tweaks.showGrid}
                onChange={e => {
                  updateTweak("showGrid", e.target.checked);
                  document.documentElement.classList.toggle("no-grid", !e.target.checked);
                }}
              />
            </label>
          </div>
        </div>
      )}
    </div>
  );
}

// Mini aperçu SVG pour les cartes profils
function ProfileThumb({ profile }) {
  const G = window.AluGeom;
  const pts = G.computePolyline(profile.segments, profile.bends);
  const flipped = pts.map(p => ({ x: p.x, y: -p.y }));
  const bb = G.bbox(flipped);
  const pad = 8;
  const vb = { x: bb.minX - pad, y: bb.minY - pad, w: bb.w + pad * 2, h: bb.h + pad * 2 };
  return (
    <svg viewBox={`${vb.x} ${vb.y} ${vb.w} ${vb.h}`} preserveAspectRatio="xMidYMid meet" style={{ width: "100%", height: "100%" }}>
      <polyline
        points={flipped.map(p => `${p.x},${p.y}`).join(" ")}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinejoin="miter"
      />
    </svg>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);

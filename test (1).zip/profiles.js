// profiles.js — catalogue des profils standards
// Chaque profil = { id, nom, description, segments: [{length,label}], bends: [{angle}] }
// Angles convention : positif = pli anti-horaire (vers le haut), négatif = horaire (vers le bas)
// On part toujours horizontal vers la droite.

(function () {
  const PROFILES = [
    {
      id: "bavette_simple",
      name: "Bavette simple",
      subtitle: "2 plis",
      segments: [
        { length: 40, label: "A" },  // retombée arrière
        { length: 200, label: "B" }, // partie horizontale / recouvrement
        { length: 25, label: "C" },  // pli avant (larmier)
      ],
      bends: [
        { angle: -90 }, // descente du retour
        { angle: -90 }, // larmier vers le bas
      ],
    },
    {
      id: "bavette_casse_goutte",
      name: "Bavette avec casse-goutte",
      subtitle: "4 plis",
      segments: [
        { length: 40, label: "A" },
        { length: 200, label: "B" },
        { length: 25, label: "C" },
        { length: 15, label: "D" },
        { length: 10, label: "E" },
      ],
      bends: [
        { angle: -90 },
        { angle: -90 },
        { angle: -90 },
        { angle: 90 },
      ],
    },
    {
      id: "couvertine_pente_int",
      name: "Couvertine pente intérieure",
      subtitle: "4 plis — évacuation côté intérieur",
      segments: [
        { length: 50, label: "A" },  // retombée côté extérieur (haute)
        { length: 300, label: "B" }, // plateau (avec pente implicite dans la pose)
        { length: 40, label: "C" },  // retombée intérieure (basse)
        { length: 20, label: "D" },  // retour pincé
        { length: 15, label: "E" },
      ],
      bends: [
        { angle: -92 }, // léger contre-pli pour la pente
        { angle: -88 },
        { angle: -90 },
        { angle: 90 },
      ],
    },
    {
      id: "couvertine_pente_ext",
      name: "Couvertine pente extérieure",
      subtitle: "4 plis — évacuation côté façade",
      segments: [
        { length: 40, label: "A" },
        { length: 300, label: "B" },
        { length: 50, label: "C" },
        { length: 20, label: "D" },
        { length: 15, label: "E" },
      ],
      bends: [
        { angle: -88 },
        { angle: -92 },
        { angle: -90 },
        { angle: 90 },
      ],
    },
    {
      id: "couvertine_plate",
      name: "Couvertine plate",
      subtitle: "Symétrique",
      segments: [
        { length: 45, label: "A" },
        { length: 20, label: "B" },
        { length: 300, label: "C" },
        { length: 20, label: "D" },
        { length: 45, label: "E" },
      ],
      bends: [
        { angle: 90 },
        { angle: 90 },
        { angle: -90 },
        { angle: -90 },
      ],
    },
    {
      id: "solin",
      name: "Solin / Engravure",
      subtitle: "3 plis",
      segments: [
        { length: 30, label: "A" },  // partie engravée
        { length: 20, label: "B" },
        { length: 80, label: "C" },  // retombée
        { length: 15, label: "D" },  // casse-goutte
      ],
      bends: [
        { angle: -90 },
        { angle: -90 },
        { angle: -90 },
      ],
    },
    {
      id: "libre",
      name: "Profil libre",
      subtitle: "Sur-mesure — ajout/suppression de plis",
      segments: [
        { length: 50, label: "A" },
        { length: 100, label: "B" },
        { length: 50, label: "C" },
      ],
      bends: [
        { angle: -90 },
        { angle: -90 },
      ],
    },
  ];

  window.AluProfiles = PROFILES;
})();
